import matplotlib.pyplot as plt

xAxis = ['MATH', 'BIOL',  'CSCI', 'COMM', 'NURS', 'MUSC']
yAxis = [2.819, 2.996, 3.235, 3.330, 3.789, 3.739]    
plt.bar(xAxis, yAxis, color=['blue', 'red'])
plt.xlabel('Student Major')
plt.ylabel('Average GPA')
plt.title('Average GPA by Student Major (AY2017-18)')
plt.show()